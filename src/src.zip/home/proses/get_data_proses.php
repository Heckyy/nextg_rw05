<?php
session_start();

include_once "./../../../core/file/function_proses.php";
include_once "./../../../core/file/services/bankReportService.php";
include_once "./../../../core/file/services/closeBookService.php";
$closeBook = new closeBook();
if (!$closeBook->isLastDayOfMonth()) {
    return;
} else {
    $closeBook->closeBook();
}
