<?php
class input_saldo
{
    function view_input_saldo()
    { ?>
        <div class="app-card-header p-3 main-content container-fluid">
            <div class="row justify-content-between align-items-center line">
                <div class="col-auto">
                    <h6 class="app-card-title">
                        Input Begining Saldo
                    </h6>
                </div>
            </div>
        </div>

<?php
    }
}

?>