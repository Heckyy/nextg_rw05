<?php
	session_start();

	if(!empty($_SESSION['id_employee']) && !empty($_POST['proses'])){
		include_once "./../../../core/file/function_proses.php";
		$db = new db();

		if($_POST['proses']=='tarik_data'){


			$perPage = 10;
			if (isset($_POST["page"])) { 
				$page  = $_POST["page"]; 
			} else { 
				$page=1; 
			};  
			$startFrom = ($page-1) * $perPage;  

			$e=mysqli_fetch_assoc($db->select('tb_settings','id_settings','id_settings','DESC'));

			if(!empty($_POST['cari'])){
				$ubah_pencarian=mysqli_real_escape_string($db->query, str_replace('and_symbol', '&', $_POST['cari']));
			}else{
				$ubah_pencarian="";
			}

			$data = $db->selectpage('tb_item','code_item LIKE "%'.$ubah_pencarian.'%" || item LIKE "%'.$ubah_pencarian.'%"','code_item','ASC',$startFrom,$perPage,'id_item,code_item,item,type_of_item,note');

			$no=$startFrom+1;


			if(mysqli_num_rows($data) > 0 ){
				$jum=mysqli_num_rows($data);
				$i=1;
				$rows = '[';

				foreach ($data as $key => $v) {


					$type_of_item=$db->select('tb_type_of_item','id_type_of_item="'.$v['type_of_item'].'"','type_of_item','ASC');
					$t=mysqli_fetch_assoc($type_of_item);

					$ubah=str_replace("=", "", base64_encode($v['code_item']));

					$rows.='{"no":"'.$no.'",';
					$rows.='"target":"'.$ubah.'",';
					$rows.='"code_item":"'.$v["code_item"].'",';
					$rows.='"item":"'.$v["item"].'",';
					$rows.='"type_of_item":"'.$t['type_of_item'].'",';
					$rows.='"note":"'.$v["note"].'"}'; 

					$no++;

					if($i<$jum){
						$rows .= ",";
						$i++;
					}
				}

				$rows = $rows.']';

				echo $rows;

			}
		}

	}
?>
